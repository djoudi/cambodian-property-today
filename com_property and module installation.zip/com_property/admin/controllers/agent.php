<?php
// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

class PropertyControllerAgent extends JControllerForm
{
    protected $text_prefix = 'com_property';
	
}