<?php
// no direct access
defined('_JEXEC') or die;
jimport('joomla.application.component.controllerform');
class PropertyControllerDistrict extends JControllerForm
{
    protected $text_prefix = 'com_property';
    
}