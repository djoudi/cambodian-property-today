DROP TABLE  jos_ch_agent
DROP TABLE  jos_ch_booking
DROP TABLE  jos_ch_district
DROP TABLE  jos_ch_members
DROP TABLE  jos_ch_owner
DROP TABLE  jos_ch_property
DROP TABLE  jos_ch_province
