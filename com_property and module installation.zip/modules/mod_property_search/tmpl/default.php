<?php
defined('_JEXEC') or die;
?>
<form id="load-calculator" name="loan-calculator" >
    <div>
        <div class="label">

        </div>
        <div class="elm" > </div>
    </div>
</form>
