<div>
    <script type="text/javascript" >
	<?php 
		$code = $params->get("code");
		echo $code ;
	?>
    </script>
    
    <script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
    
    <?php
       // $doc =& JFactory::getDocument();
       // $doc->addScript("http://pagead2.googlesyndication.com/pagead/show_ads.js");
    ?>

</div>
